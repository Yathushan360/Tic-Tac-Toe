Tic Tac Toe Game (C)

Files :

1. game.c - Main program file (game logic and menu)
2. tictactoe.c - Contains function definitions used in the game
3. tictactoe.h - Header file with function declarations
4. tic-tac-toe_log.txt - Automatically created file that stores game history

How to Compile :

Run this command in terminal :

gcc game.c tictactoe.c -o tic-tac-toe

This will create an executable file named 'tic-tac-toe'.

 How to Run :
    ./tic-tac-toe
    
Notes :
Each time you play, game results are saved in "tic-tac-toe_log.txt".
The log file is opened in append mode, so previous game histories are kept.

Enjoy the game! 🎮
